using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;
using Newtonsoft.Json;


// API key e05079bc-8457-4452-9882-57240276e829
public class ApiManager : MonoBehaviour
{
    public PokemonMultiData cards;
    private string request;

    private void Awake()
    {
        //request = "https://api.pokemontcg.io/v2/cards/xy1-1";
        request = "https://api.pokemontcg.io/v2/cards";

        StartCoroutine(ApiRequest(request));
    }


    public IEnumerator ApiRequest(string url)
    {
        UnityWebRequest www = new UnityWebRequest();
        www = UnityWebRequest.Get(url);

        //auth
        www.SetRequestHeader("Authorization", "Bearer e05079bc-8457-4452-9882-57240276e829");
        //www.SetRequestHeader("x-api-key", "e05079bc-8457-4452-9882-57240276e829");

        www.downloadHandler = new DownloadHandlerBuffer();

        yield return www.SendWebRequest();

        if (www.result == UnityWebRequest.Result.ConnectionError)
        {
            Debug.Log("NetworkError: " + www.error);
        }

        string rawJson = Encoding.Default.GetString(www.downloadHandler.data);
        cards = JsonConvert.DeserializeObject<PokemonMultiData>(rawJson);
        //Debug.Log("cards[0] small image: " + cards.data[0].images.small); // ok, great!

        this.GetComponent<Manager>().SetUpCardCollection();

        Debug.Log(rawJson);       
    }

    public PokemonMultiData GetAllCards()
    {
        return cards;
    }  
}
