using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

public class Manager : MonoBehaviour
{
    public GameObject CardPrefab;
    public Transform ContentTransform;

    public void SetUpCardCollection()
    {
        ClearContentsOf(ContentTransform);
        PokemonMultiData cards = this.gameObject.GetComponent<ApiManager>().cards;//GetAllCards();

        Debug.Log("cards size: " + cards.data.Count);
        foreach (Data item in cards.data)
        {
            GameObject newCard_GO = Instantiate(CardPrefab, ContentTransform);

            Debug.Log("new card GO: " + newCard_GO);
            StartCoroutine(LoadImageFromURL(item.images.small, newCard_GO.GetComponent<Image>()));
        }

        //int pageCount; //3ekina me 0

        //int minCount = pageCount * 20;

        //int maxCount = minCount + 20;

        //for (int i = minCount; i < maxCount; i++)
        //{ 

        //}
        // k otan patas next pas pageCount++ k 3anakaneis instanitae ts epomenes
        // 8a kaneis na elegxo an to maxCount einai megalitero apo to length tou 
        //cards array tote to maxCount einai to length tou array. 
        //emmm opws exeis tora to scroll content. na mpoun apo katw. 
        //ena next button de3ia, ena previous button aristera. k sti mesi 8a leei "Page 1/100"
    }



    public IEnumerator LoadImageFromURL(string URL, Image cell)
    {
        if (!string.IsNullOrEmpty(URL))
        {
            // Check internet connection
            if (Application.internetReachability == NetworkReachability.NotReachable)
            {
                yield return null;
            }
            UnityWebRequest www = UnityWebRequestTexture.GetTexture(URL);
            yield return www.SendWebRequest();

            Texture2D loadedTexture = DownloadHandlerTexture.GetContent(www);
            cell.sprite = Sprite.Create(loadedTexture, new Rect(0f, 0f, loadedTexture.width, loadedTexture.height), Vector2.zero);
        }
    }

    public void ClearContentsOf(Transform item)
    {
        for (int i = item.childCount-1; i >= 0; i--)
        {
            GameObject.Destroy(item.GetChild(i).gameObject);
        }
    }
}
